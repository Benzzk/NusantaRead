export const API_KEY = API_KEY_VALUE;
export const GOOGLE_BOOKS_URL = 'https://www.googleapis.com/books';
export const KEY_HEADER = '&key=' + API_BOOKS_KEY;
export const FREE_BOOKS_ENPOINT = '/v1/volumes?q=flowers&filter=free-ebooks';
export const ALL_EBOOKS_ENDPOInT = '/v1/volumes?q=';
